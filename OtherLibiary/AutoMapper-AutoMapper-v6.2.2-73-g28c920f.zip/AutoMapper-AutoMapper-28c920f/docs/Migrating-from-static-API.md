# Migrating from Static API

This document has been removed since migrating from Static API is no longer necessary. It is still there per Jimmy Bogard
