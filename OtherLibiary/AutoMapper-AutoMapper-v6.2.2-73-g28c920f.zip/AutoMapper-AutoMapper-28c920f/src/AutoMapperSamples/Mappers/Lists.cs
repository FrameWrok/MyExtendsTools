using System.Collections.Generic;
using AutoMapper;
using Shouldly;
using NUnit.Framework;
using System.Linq;

namespace AutoMapperSamples.Mappers
{
    namespace Lists
    {
        [TestFixture]
        public class SimpleExample
        {
            public class Source
            {
                public int Value { get; set; }
            }

            public class Destination
            {
                public int Value { get; set; }
            }

            [Test]
            public void Example()
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<Source, Destination>();
                });

                var sources = new[]
                    {
                        new Source {Value = 5},
                        new Source {Value = 6},
                        new Source {Value = 7}
                    };

                IEnumerable<Destination> ienumerableDest = config.CreateMapper().Map<Source[], IEnumerable<Destination>>(sources);
                ICollection<Destination> icollectionDest = config.CreateMapper().Map<Source[], ICollection<Destination>>(sources);
                IList<Destination> ilistDest = config.CreateMapper().Map<Source[], IList<Destination>>(sources);
                List<Destination> listDest = config.CreateMapper().Map<Source[], List<Destination>>(sources);

                ienumerableDest.Count().ShouldBe(3);
                icollectionDest.Count().ShouldBe(3);
                ilistDest.Count().ShouldBe(3);
                listDest.Count().ShouldBe(3);
            }
        }

        [TestFixture]
        public class PolymorphicExample
        {
            public class ParentSource
            {
                public int Value1 { get; set; }
            }

            public class ChildSource : ParentSource
            {
                public int Value2 { get; set; }
            }

            public class ParentDestination
            {
                public int Value1 { get; set; }
            }

            public class ChildDestination : ParentDestination
            {
                public int Value2 { get; set; }
            }

            [Test]
            public void Example()
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<ParentSource, ParentDestination>()
                        .Include<ChildSource, ChildDestination>();
                    cfg.CreateMap<ChildSource, ChildDestination>();
                });

                var sources = new[]
                    {
                        new ParentSource(),
                        new ChildSource(),
                        new ParentSource()
                    };

                var destinations = config.CreateMapper().Map<ParentSource[], ParentDestination[]>(sources);

                destinations[0].ShouldBeOfType<ParentDestination>();
                destinations[1].ShouldBeOfType<ChildDestination>();
                destinations[2].ShouldBeOfType<ParentDestination>();
            }
        }
    }
}