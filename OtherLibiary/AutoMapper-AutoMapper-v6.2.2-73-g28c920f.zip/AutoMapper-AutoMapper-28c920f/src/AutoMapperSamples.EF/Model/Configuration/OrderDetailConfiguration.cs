﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoMapperSamples.EF.Model.Configuration
{
    //public class OrderDetailConfiguration : EntityTypeConfiguration<OrderDetail>
    //{
    //    public OrderDetailConfiguration()
    //    {
    //        HasKey(od => new {od.OrderID, od.ProductID});
    //        HasRequired(od => od.Order).WithMany(o => o.OrderDetails).HasForeignKey(od => od.OrderID);
    //        HasRequired(od => od.Product);
    //    }
    //}
}
