﻿using System;

namespace OmmitedDTOModel3
{
    public class EntityDTO9 : BaseEntity
    {
        public Guid Entity3Id { get; set; }
        public EntityDTO3 Entity3 { get; set; }
    }
}
