﻿using System;

namespace OmmitedDatabaseModel3
{
    public class Entity9 : BaseEntity
    {
        public Guid Entity3Id { get; set; }
        public Entity3 Entity3 { get; set; }
    }
}
