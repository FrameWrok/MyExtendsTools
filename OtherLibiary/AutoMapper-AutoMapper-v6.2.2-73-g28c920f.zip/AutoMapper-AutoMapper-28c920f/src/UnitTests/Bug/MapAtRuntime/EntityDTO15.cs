﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3
{
    public class EntityDTO15 : BaseEntity
    {
        public EntityDTO15()
        {
        }
        public Guid Entity17Id { get; set; }
        public EntityDTO17 Entity17 { get; set; }
    }
}
