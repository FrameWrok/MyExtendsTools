﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3
{
    public class EntityDTO12 : BaseEntity
    {
        public EntityDTO12()
        {
            //this.Entities20 = new EntityDTO20();
            //this.Entities14 = new EntityDTO14();
            //Entities16 = new EntityDTO16();
        }
        public EntityDTO20 Entities20 { get; set; }
        public EntityDTO16 Entities16 { get; set; }
        public EntityDTO14 Entities14 { get; set; }
    }
}
