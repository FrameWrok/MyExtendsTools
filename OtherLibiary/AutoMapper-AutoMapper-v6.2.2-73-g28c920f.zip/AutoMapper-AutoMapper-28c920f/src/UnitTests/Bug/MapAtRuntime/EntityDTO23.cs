﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3
{
    public class EntityDTO23 : BaseEntity
    {
        public Guid Entity5Id { get; set; }
        public EntityDTO5 Entity5 { get; set; }
    }
}
