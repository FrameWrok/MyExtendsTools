﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDatabaseModel3
{
    public class Entity24 : BaseEntity
    {
        public Guid Entity3Id { get; set; }
        public Entity3 Entity3 { get; set; }
        public Guid Entity22Id { get; set; }
        public Entity22 Entity22 { get; set; }
    }
}
