﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3
{
    public class EntityDTO5 : BaseEntity
    {
        public EntityDTO5()
        {
            //this.Entities6 = new EntityDTO6();
            //this.TimeSlots = new EntityDTO23();
            //this.Entities5 = new EntityDTO5();
        }

        public Guid? Entity8Id { get; set; }
        public EntityDTO8 Entity8 { get; set; }
        public Guid? Entity17Id { get; set; }
        public EntityDTO17 Entity17 { get; set; }
        public Guid? Entity5Id { get; set; }
        public EntityDTO5 Entity5Exception { get; set; }
        public EntityDTO5 Entities5 { get; set; }
        public EntityDTO6 Entities6 { get; set; }
        public EntityDTO23 TimeSlots { get; set; }
    }
}
