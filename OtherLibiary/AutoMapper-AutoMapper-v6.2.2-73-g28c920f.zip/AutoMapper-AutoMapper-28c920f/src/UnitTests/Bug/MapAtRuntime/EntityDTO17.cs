﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3
{
    public class EntityDTO17 :BaseEntity
    {
        public EntityDTO17()
        {
            //this.Entities20 = new EntityDTO20();
            //this.Entities8 = new EntityDTO8();
            //this.Entities5 = new EntityDTO5();
            //this.Entities18 = new EntityDTO18();
        }

        public EntityDTO20 Entities20 { get; set; }
        public EntityDTO8 Entities8 { get; set; }
        public EntityDTO5 Entities5 { get; set; }
        public EntityDTO18 Entities18 { get; set; }
    }
}
