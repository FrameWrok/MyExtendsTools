﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDatabaseModel3
{
    public class Entity26 : BaseEntity
    {
        public Entity26()
        {
            //this.Entities20 = new Entity20();
        }

        public Entity20 Entities20 { get; set; }
    }
}
