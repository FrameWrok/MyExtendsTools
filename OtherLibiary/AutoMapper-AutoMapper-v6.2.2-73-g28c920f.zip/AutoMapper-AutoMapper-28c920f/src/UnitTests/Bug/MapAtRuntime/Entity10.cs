﻿using System.Collections.Generic;

namespace OmmitedDatabaseModel3
{
    public class Entity10 : BaseEntity
    {
        public Entity10()
        {
            this.Entities11 = new Entity11();
        }
        public Entity11 Entities11 { get; set; }
    }
}
