﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDatabaseModel3WithCollections
{
    public class Entity16 : BaseEntity
    {
        public Guid Entity20Id { get; set; }
        public Entity20 Entity20 { get; set; }
        public Guid Entity12Id { get; set; }
        public Entity12 Entity12 { get; set; }
    }
}
