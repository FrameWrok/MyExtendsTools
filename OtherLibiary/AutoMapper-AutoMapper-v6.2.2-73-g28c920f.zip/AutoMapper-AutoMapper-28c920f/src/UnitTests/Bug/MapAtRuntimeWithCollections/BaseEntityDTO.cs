﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDTOModel3WithCollections
{
    public class BaseEntity
    {
        public Guid Id { get; set; }
    }
}
