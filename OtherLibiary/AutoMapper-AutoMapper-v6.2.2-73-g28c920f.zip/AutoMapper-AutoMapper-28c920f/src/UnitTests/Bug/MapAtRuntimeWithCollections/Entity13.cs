﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OmmitedDatabaseModel3WithCollections
{
    public class Entity13 : BaseEntity
    {
        public Guid Entity17Id { get; set; }
        public Entity17 Entity17 { get; set; }
        public Guid Entity8Id { get; set; }
        public Entity8 Entity8 { get; set; }
    }
}
