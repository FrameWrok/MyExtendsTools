﻿using System;

namespace OmmitedDatabaseModel3WithCollections
{
    public class Entity19 : BaseEntity
    {
        public Guid Entity25Id { get; set; }
        public Entity25 Entity25 { get; set; }
    }
}
