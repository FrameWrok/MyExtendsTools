namespace AutoMapper.Configuration.Conventions
{
    public class DefaultName : CaseSensitiveName
    {
    }
}