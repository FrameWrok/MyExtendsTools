/opt/mssql/bin/sqlservr & ./import-data.sh
while :; do
  sleep 300
done
